const express = require("express");
const cors = require("cors");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const app = express();
require("dotenv").config();

app.use(cors({ origin: true }));
app.use(express.json());

const storeItems = new Map([
  ["price_1SQf0IGXoS6YuhipQQEN7Lxo", { name: "Classic Lowrider Black Tee", priceInCents: 2999 }],
  ["price_1SQf0JXoS6YuhipUOTHERID", { name: "Classic Lowrider Hoodie", priceInCents: 4999 }]
]);

app.post("/create-checkout-session", async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      line_items: req.body.items.map(item => {
        const storeItem = storeItems.get(item.id);
        return {
          price: item.id,
          quantity: item.quantity,
        };
      }),
      success_url: "https://lowridermonth.com/success",
      cancel_url: "https://lowridermonth.com/cancel"
    });
    res.json({ url: session.url });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
